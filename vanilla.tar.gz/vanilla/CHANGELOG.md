## vanilla-0.1.0.rc7 TODO LIST

* Full support OPM
* Add Lemplate as A default View engine
